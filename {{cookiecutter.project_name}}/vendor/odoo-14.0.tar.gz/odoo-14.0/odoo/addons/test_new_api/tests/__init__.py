# -*- coding: utf-8 -*-

from . import test_new_fields
from . import test_onchange
from . import test_attributes
from . import test_one2many
from . import test_qweb_float
from . import test_ui
from . import test_domain
from . import test_schema
from . import test_company_checks
