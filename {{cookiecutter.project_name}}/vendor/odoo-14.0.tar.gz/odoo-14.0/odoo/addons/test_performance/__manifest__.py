# -*- coding: utf-8 -*-
{
    'name': "Test Performance",
    'version': "1.0",
    'category': "Hidden",
    'depends': ['base'],
    'data': [
        'security/ir.model.access.csv',
    ],
    'license': 'LGPL-3',
}
