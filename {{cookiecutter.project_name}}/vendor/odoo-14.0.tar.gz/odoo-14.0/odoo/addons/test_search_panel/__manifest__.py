# -*- coding: utf-8 -*-
{
    'name': "test_search_panel",
    'description': "Tests for the search panel python methods",

    'category': 'Hidden/Tests',
    'version': '0.1',

    'depends': ['web'],

    'data': ['ir.model.access.csv'],
    'license': 'LGPL-3',
}
