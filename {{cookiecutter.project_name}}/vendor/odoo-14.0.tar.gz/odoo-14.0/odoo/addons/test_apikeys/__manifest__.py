# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name': 'Tests flow of API keys',
    'category': 'Tools',
    'depends': ['web_tour'],
    'data': ['views/assets.xml'],
    'license': 'LGPL-3',
}
