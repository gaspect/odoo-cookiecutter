{
    'name': "Test Action Bindings",
    'category': 'Hidden/Tests',
    'data': [
        'ir.model.access.csv',
        'test_data.xml',
    ],
    'license': 'LGPL-3',
}
