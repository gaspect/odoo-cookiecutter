from . import test_pylint
from . import test_pofile
from . import test_ecmascript
from . import test_markers
from . import test_onchange_domains
from . import test_dunderinit
from . import test_jstranslate
