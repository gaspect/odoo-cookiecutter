from . import test_data_module_installed
